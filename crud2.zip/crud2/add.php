<?php 
include 'db.php';

if(isset($_POST['send'])){


$amount = htmlspecialchars($_POST['amount']);
$profit = htmlspecialchars($_POST['profit']);


$sql = "insert into tasks (amount, profit) values ('$amount','$profit')";

$val = $db->query($sql);

if($val){

	header('location: index.php');
}else{

	echo "error";
}

}



 ?>